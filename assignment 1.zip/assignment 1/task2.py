a=str(input("Enter your first name: "))
b=str(input("Enter your last name: "))

c=a+" "+b
print("Hello,",c,"! Welcome to Python program.")